package com.exam.ex_rec_card.Activities;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.exam.ex_rec_card.MainActivity;
import com.exam.ex_rec_card.R;

public class SplashScreen extends Activity {
    Animation uptodown,downtoup;

    LinearLayout first,second;

    AnimationDrawable empaAnimation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        first=(LinearLayout)findViewById(R.id.first);
        second=(LinearLayout)findViewById(R.id.second);
        uptodown = AnimationUtils.loadAnimation(this,R.anim.uptodown);
        downtoup = AnimationUtils.loadAnimation(this,R.anim.downtoup);
        first.setAnimation(uptodown);
        second.setAnimation(downtoup);

        ImageView imageView =(ImageView)findViewById(R.id.image);
        imageView.setBackgroundResource(R.drawable.animation);
        empaAnimation=(AnimationDrawable) imageView.getBackground();
        empaAnimation.start();

        Thread timerThread= new Thread(){
            public void run(){
                try {
                    sleep(5000);
                }catch (InterruptedException e) {
                    e.printStackTrace();
                }finally {
                    Intent i = new Intent(SplashScreen.this, MainActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                }
            }
        };
        timerThread.start();
    }

}
