package com.exam.ex_rec_card.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.TextView;

import com.exam.ex_rec_card.Adapters.RecyclerAdapterStep2Item;
import com.exam.ex_rec_card.Model.RecylerStep2ItemModel;
import com.exam.ex_rec_card.R;

import java.util.ArrayList;
import java.util.List;

public class Step2Activity extends AppCompatActivity {


    RecyclerView rcyStep2;

    RecyclerView.LayoutManager manager;
    RecyclerAdapterStep2Item adapter;
    String kim;
    TextView tv_title;
    Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_step2);
        toolbar=findViewById(R.id.toolbar_step2);

        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        tv_title=findViewById(R.id.toolbar_title_step2);
        rcyStep2=findViewById(R.id.recycler_step2);
        rcyStep2.setHasFixedSize(true);
        manager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false);
        rcyStep2.setLayoutManager(manager);

        Intent i=getIntent();
        kim=i.getStringExtra("kim");
        tv_title.setText(kim.toUpperCase());

        List<String> ofisIsimleri=new ArrayList<>();
        ofisIsimleri.add("Büyük Toplantı Odası");
        ofisIsimleri.add("Küçük Toplantı Odası");
        ofisIsimleri.add("Orta Toplantı Odasi");
        ofisIsimleri.add("Elektronik Ofis");
        ofisIsimleri.add("Teknoloji Ofis");
        ofisIsimleri.add("Enerji  Ofis");

        List<String> nemler=new ArrayList<>();
        nemler.add("%29");
        nemler.add("%25");
        nemler.add("%19");
        nemler.add("%23");

        List<String > gurultuler=new ArrayList<>();
        gurultuler.add("%30");
        gurultuler.add("%23");
        gurultuler.add("%18");
        gurultuler.add("%21");

        List<String > sicakliklar=new ArrayList<>();
        sicakliklar.add("18 C");
        sicakliklar.add("22 C");
        sicakliklar.add("29 C");
        sicakliklar.add("32 C");

        List<String > cerceveBelirle=new ArrayList<>();
        cerceveBelirle.add("1");
        cerceveBelirle.add("0");
        cerceveBelirle.add("1");
        cerceveBelirle.add("0");

        if (kim!=null){
            if (kim.equals("elektronik")){
                List<RecylerStep2ItemModel> rls=new ArrayList<>();

                for (int j = 0; j < 4; j++) {
                    RecylerStep2ItemModel rm=new RecylerStep2ItemModel();
                    rm.setGurultu(gurultuler.get(j));
                    rm.setNem(nemler.get(j));
                    rm.setOfisAdi(ofisIsimleri.get(j));
                    rm.setSicaklikBelirle(cerceveBelirle.get(j));
                    rm.setSicaklik(sicakliklar.get(j));
                    rm.setLayoutbg(R.drawable.blured);

                    rls.add(rm);
                }
                adapter=new RecyclerAdapterStep2Item(rls);
                rcyStep2.setAdapter(adapter);
            }else if (kim.equals("teknoloji")
                    || kim.equals("enerji")){
                List<RecylerStep2ItemModel> rls=new ArrayList<>();

                for (int j = 0; j < 3; j++) {
                    RecylerStep2ItemModel rm=new RecylerStep2ItemModel();
                    rm.setGurultu(gurultuler.get(j));
                    rm.setNem(nemler.get(j));
                    if (j==2){
                        if (kim.equals("teknoloji")){
                            rm.setOfisAdi("Teknoloji Ofis");

                        }
                        if (kim.equals("enerji")){
                            rm.setOfisAdi("Enerji Ofis");
                        }
                    }

                    if (j<2)
                    rm.setOfisAdi(ofisIsimleri.get(j));

                    rm.setSicaklikBelirle(cerceveBelirle.get(j));
                    rm.setSicaklik(sicakliklar.get(j));
                    rm.setLayoutbg(R.drawable.blured);

                    rls.add(rm);
                }
                adapter=new RecyclerAdapterStep2Item(rls);
                rcyStep2.setAdapter(adapter);
            }
        }

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // handle arrow click here
        if (item.getItemId() == android.R.id.home) {
            finish(); // close this activity and return to preview activity (if there is any)
        }

        return super.onOptionsItemSelected(item);
    }
}
