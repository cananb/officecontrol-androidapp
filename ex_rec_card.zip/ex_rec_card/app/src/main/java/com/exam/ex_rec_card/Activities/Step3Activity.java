package com.exam.ex_rec_card.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.TextView;

import com.exam.ex_rec_card.R;

public class Step3Activity extends AppCompatActivity {


    String nem,sicaklik,gurultu,ofisAdi;
    Toolbar toolbar;
    TextView tv_nem,tv_sicaklik,tv_gurultu,tv_title;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_step3);

        toolbar=(Toolbar)findViewById(R.id.toolbar_step3);

        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        tv_nem=findViewById(R.id.tv_step3_nem);
        tv_gurultu=findViewById(R.id.tv_step3_gurultu);
        tv_sicaklik=findViewById(R.id.tv_step3_sicaklik);
        tv_title=findViewById(R.id.toolbar_title_step3);

        Intent i=getIntent();
        nem=i.getStringExtra("nem");
        sicaklik=i.getStringExtra("sicaklik");
        gurultu=i.getStringExtra("gurultu");
        ofisAdi=i.getStringExtra("ofisAdi");

        tv_title.setText(ofisAdi);
        tv_sicaklik.setText(sicaklik);
        tv_gurultu.setText(gurultu);
        tv_nem.setText(nem);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // handle arrow click here
        if (item.getItemId() == android.R.id.home) {
            finish(); // close this activity and return to preview activity (if there is any)
        }

        return super.onOptionsItemSelected(item);
    }
}
