package com.exam.ex_rec_card.Model;

/**
 * Created by Ahmet on 24.4.2018.
 */

public class RecylerItemModel {
    String title;
    String descp;
    int icon;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescp() {
        return descp;
    }

    public void setDescp(String descp) {
        this.descp = descp;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }
}
