package com.exam.ex_rec_card.Model;

/**
 * Created by Ahmet on 24.4.2018.
 */

public class RecylerStep2ItemModel {
    String sicaklikBelirle;
    String nem;
    String gurultu;
    String sicaklik;
    int layoutbg;
    String ofisAdi;


    public String getSicaklikBelirle() {
        return sicaklikBelirle;
    }

    public void setSicaklikBelirle(String sicaklikBelirle) {
        this.sicaklikBelirle = sicaklikBelirle;
    }

    public String getNem() {
        return nem;
    }

    public void setNem(String nem) {
        this.nem = nem;
    }

    public String getGurultu() {
        return gurultu;
    }

    public void setGurultu(String gurultu) {
        this.gurultu = gurultu;
    }

    public String getSicaklik() {
        return sicaklik;
    }

    public void setSicaklik(String sicaklik) {
        this.sicaklik = sicaklik;
    }

    public int getLayoutbg() {
        return layoutbg;
    }

    public void setLayoutbg(int layoutbg) {
        this.layoutbg = layoutbg;
    }

    public String getOfisAdi() {
        return ofisAdi;
    }

    public void setOfisAdi(String ofiAdi) {
        this.ofisAdi = ofiAdi;
    }
}
